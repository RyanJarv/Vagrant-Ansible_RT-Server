// RT's styles have some crazy z-indexes, so get above 'em all by default.
jQuery.modal.defaults.zIndex = 9999;
